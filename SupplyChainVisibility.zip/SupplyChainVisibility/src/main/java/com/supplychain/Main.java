package com.supplychain;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;


public class Main {


    static final Color DARK = new Color(45, 45, 45);
    static final Color LIGHT = new Color(245, 245, 245);
    static final Color BORDER = new Color(200, 200, 200);

    static Font normalFont = new Font("Arial", Font.PLAIN, 14);
    static Font boldFont = new Font("Arial", Font.BOLD, 14);
    static Font titleFont = new Font("Arial", Font.BOLD, 22);


    enum ShipmentStatus {
        CREATED, PACKED, DISPATCHED, IN_TRANSIT,
        ARRIVED, DELIVERED, DELAYED, CANCELLED
    }

    static class Shipment {
        String id;
        String origin;
        String destination;
        String product;
        String vehicle;
        String expectedDelivery;
        ShipmentStatus status;

        Shipment(String id, String origin, String destination,
                 String product, String vehicle,
                 String expectedDelivery, ShipmentStatus status) {

            this.id = id;
            this.origin = origin;
            this.destination = destination;
            this.product = product;
            this.vehicle = vehicle;
            this.expectedDelivery = expectedDelivery;
            this.status = status;
        }
    }

    static class Event {
        String shipmentId;
        String date;
        String location;
        String status;

        Event(String shipmentId, String date,
              String location, String status) {
            this.shipmentId = shipmentId;
            this.date = date;
            this.location = location;
            this.status = status;
        }
    }

    static class Inventory {
        String productId;
        String product;
        String warehouse;
        int quantity;
        int reorderLevel;

        Inventory(String productId, String product,
                  String warehouse, int quantity,
                  int reorderLevel) {

            this.productId = productId;
            this.product = product;
            this.warehouse = warehouse;
            this.quantity = quantity;
            this.reorderLevel = reorderLevel;
        }
    }

    static class Supplier {
        String id;
        String name;
        String contact;
        String email;
        String product;

        Supplier(String id, String name, String contact,
                 String email, String product) {

            this.id = id;
            this.name = name;
            this.contact = contact;
            this.email = email;
            this.product = product;
        }
    }

    static class Warehouse {
        String id;
        String name;
        String location;
        int capacity;
        int occupied;

        Warehouse(String id, String name, String location,
                  int capacity, int occupied) {

            this.id = id;
            this.name = name;
            this.location = location;
            this.capacity = capacity;
            this.occupied = occupied;
        }

        double utilization() {
            if (capacity == 0) return 0;
            return occupied * 100.0 / capacity;
        }
    }

    static class Vehicle {
        String id;
        String number;
        String type;
        String driver;
        String status;

        Vehicle(String id, String number, String type,
                String driver, String status) {

            this.id = id;
            this.number = number;
            this.type = type;
            this.driver = driver;
            this.status = status;
        }
    }

    static class Alert {
        String id;
        String type;
        String description;
        String severity;
        boolean resolved;

        Alert(String id, String type,
              String description, String severity) {

            this.id = id;
            this.type = type;
            this.description = description;
            this.severity = severity;
            this.resolved = false;
        }
    }

    // ============================================================
    // DEMO DATA
    // ============================================================

    static List<Shipment> shipments = new ArrayList<>();
    static List<Event> events = new ArrayList<>();
    static List<Inventory> inventory = new ArrayList<>();
    static List<Supplier> suppliers = new ArrayList<>();
    static List<Warehouse> warehouses = new ArrayList<>();
    static List<Vehicle> vehicles = new ArrayList<>();
    static List<Alert> alerts = new ArrayList<>();

    static void loadDemoData() {

        shipments.add(new Shipment(
                "SHP-1023", "Delhi", "Mumbai",
                "Electronic Equipment", "UP32 AB 1234",
                "12 Sep 2026", ShipmentStatus.IN_TRANSIT));

        shipments.add(new Shipment(
                "SHP-1024", "Pune", "Delhi",
                "Industrial Parts", "MH12 XY 8899",
                "10 Sep 2026", ShipmentStatus.DELAYED));

        shipments.add(new Shipment(
                "SHP-1025", "Jaipur", "Lucknow",
                "Consumer Goods", "RJ14 CD 4455",
                "09 Sep 2026", ShipmentStatus.DELIVERED));

        shipments.add(new Shipment(
                "SHP-1026", "Delhi", "Lucknow",
                "Medical Supplies", "DL01 PQ 7788",
                "14 Sep 2026", ShipmentStatus.PACKED));

        shipments.add(new Shipment(
                "SHP-1027", "Mumbai", "Jaipur",
                "Automobile Parts", "UP78 KL 9988",
                "13 Sep 2026", ShipmentStatus.IN_TRANSIT));

        shipments.add(new Shipment(
                "SHP-1028", "Kolkata", "Delhi",
                "Raw Materials", "WB02 AA 1111",
                "15 Sep 2026", ShipmentStatus.DISPATCHED));

        shipments.add(new Shipment(
                "SHP-1029", "Delhi", "Kolkata",
                "Machinery", "DL05 BB 2222",
                "16 Sep 2026", ShipmentStatus.CREATED));

        shipments.add(new Shipment(
                "SHP-1030", "Mumbai", "Delhi",
                "Computer Parts", "MH04 CC 3333",
                "17 Sep 2026", ShipmentStatus.CREATED));

        events.add(new Event(
                "SHP-1023", "09 Sep 2026 08:00",
                "Delhi", "CREATED"));

        events.add(new Event(
                "SHP-1023", "09 Sep 2026 10:00",
                "Delhi", "PACKED"));

        events.add(new Event(
                "SHP-1023", "09 Sep 2026 14:00",
                "Delhi", "DISPATCHED"));

        events.add(new Event(
                "SHP-1023", "09 Sep 2026 18:00",
                "Jaipur", "IN_TRANSIT"));

        events.add(new Event(
                "SHP-1024", "08 Sep 2026 09:00",
                "Pune", "DISPATCHED"));

        inventory.add(new Inventory(
                "P001", "Laptop",
                "W01", 12, 20));

        inventory.add(new Inventory(
                "P002", "Computer Mouse",
                "W01", 55, 30));

        inventory.add(new Inventory(
                "P003", "Keyboard",
                "W02", 18, 25));

        inventory.add(new Inventory(
                "P004", "Industrial Sensor",
                "W03", 70, 40));

        inventory.add(new Inventory(
                "P005", "Medical Kit",
                "W02", 8, 15));

        suppliers.add(new Supplier(
                "SUP001", "ABC Electronics",
                "9876543210", "abc@example.com",
                "Electronic Equipment"));

        suppliers.add(new Supplier(
                "SUP002", "XYZ Industries",
                "9876501234", "xyz@example.com",
                "Industrial Parts"));

        suppliers.add(new Supplier(
                "SUP003", "Global Medical",
                "9123456780", "medical@example.com",
                "Medical Supplies"));

        warehouses.add(new Warehouse(
                "W01", "Delhi Central Warehouse",
                "Delhi", 1000, 650));

        warehouses.add(new Warehouse(
                "W02", "Lucknow Warehouse",
                "Lucknow", 500, 300));

        warehouses.add(new Warehouse(
                "W03", "Mumbai Warehouse",
                "Mumbai", 800, 700));

        warehouses.add(new Warehouse(
                "W04", "Jaipur Warehouse",
                "Jaipur", 600, 250));

        vehicles.add(new Vehicle(
                "V001", "UP32 AB 1234",
                "Truck", "Rajesh Kumar", "In Transit"));

        vehicles.add(new Vehicle(
                "V002", "MH12 XY 8899",
                "Truck", "Amit Singh", "Delayed"));

        vehicles.add(new Vehicle(
                "V003", "RJ14 CD 4455",
                "Van", "Ravi Sharma", "Available"));

        vehicles.add(new Vehicle(
                "V004", "DL01 PQ 7788",
                "Truck", "Suresh Yadav", "Available"));

        vehicles.add(new Vehicle(
                "V005", "UP78 KL 9988",
                "Truck", "Vikas Gupta", "In Transit"));

        alerts.add(new Alert(
                "ALT001", "Shipment Delay",
                "SHP-1024 is delayed", "HIGH"));

        alerts.add(new Alert(
                "ALT002", "Low Stock",
                "Laptop quantity is below reorder level", "MEDIUM"));

        alerts.add(new Alert(
                "ALT003", "Warehouse Capacity",
                "W03 is approaching maximum capacity", "MEDIUM"));

        alerts.add(new Alert(
                "ALT004", "Low Stock",
                "Medical Kit quantity is below reorder level", "HIGH"));

        alerts.add(new Alert(
                "ALT005", "Vehicle Maintenance",
                "RJ14 CD 4455 scheduled for maintenance", "LOW"));
    }

    // ============================================================
    // MAIN
    // ============================================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            loadDemoData();

            try {
                UIManager.setLookAndFeel(
                        UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }

            new LoginFrame();
        });
    }

    // ============================================================
    // LOGIN
    // ============================================================

    static class LoginFrame extends JFrame {

        JTextField usernameField;
        JPasswordField passwordField;

        LoginFrame() {

            setTitle("Supply Chain Visibility - Login");
            setSize(500, 350);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JPanel main = new JPanel(new BorderLayout());
            main.setBorder(new EmptyBorder(25, 30, 25, 30));

            JLabel title = new JLabel(
                    "Supply Chain Visibility and Tracking Platform",
                    SwingConstants.CENTER);

            title.setFont(new Font("Arial", Font.BOLD, 20));

            main.add(title, BorderLayout.NORTH);

            JPanel form = new JPanel(new GridLayout(4, 1, 8, 8));

            usernameField = new JTextField();
            passwordField = new JPasswordField();

            form.add(new JLabel("Username:"));
            form.add(usernameField);
            form.add(new JLabel("Password:"));
            form.add(passwordField);

            main.add(form, BorderLayout.CENTER);

            JPanel bottom = new JPanel(new BorderLayout());

            JLabel demo = new JLabel(
                    "Demo Login: admin / admin123");

            JButton login = new JButton("Login");

            login.addActionListener(e -> login());

            bottom.add(demo, BorderLayout.WEST);
            bottom.add(login, BorderLayout.EAST);

            main.add(bottom, BorderLayout.SOUTH);

            add(main);

            setVisible(true);
        }

        void login() {

            String username = usernameField.getText();
            String password =
                    new String(passwordField.getPassword());

            if (username.equals("admin")
                    && password.equals("admin123")) {

                dispose();
                new MainFrame();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Invalid username or password.",
                        "Login Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ============================================================
    // MAIN FRAME
    // ============================================================

    static class MainFrame extends JFrame {

        CardLayout cardLayout;
        JPanel contentPanel;

        MainFrame() {

            setTitle(
                    "Supply Chain Visibility and Tracking Platform");

            setSize(1200, 700);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            setLayout(new BorderLayout());

            add(createHeader(), BorderLayout.NORTH);
            add(createNavigation(), BorderLayout.WEST);

            cardLayout = new CardLayout();
            contentPanel = new JPanel(cardLayout);

            contentPanel.add(
                    new DashboardPanel(), "Dashboard");

            contentPanel.add(
                    new ShipmentPanel(), "Shipments");

            contentPanel.add(
                    new TrackingPanel(), "Tracking");

            contentPanel.add(
                    new InventoryPanel(), "Inventory");

            contentPanel.add(
                    new SupplierPanel(), "Suppliers");

            contentPanel.add(
                    new WarehousePanel(), "Warehouses");

            contentPanel.add(
                    new VehiclePanel(), "Vehicles");

            contentPanel.add(
                    new AlertPanel(), "Alerts");

            contentPanel.add(
                    new ReportPanel(), "Reports");

            add(contentPanel, BorderLayout.CENTER);

            setVisible(true);
        }

        JPanel createHeader() {

            JPanel panel = new JPanel(new BorderLayout());

            panel.setBorder(
                    BorderFactory.createMatteBorder(
                            0, 0, 1, 0, BORDER));

            panel.setPreferredSize(new Dimension(0, 55));

            JLabel title = new JLabel(
                    "  Supply Chain Visibility and Tracking Platform");

            title.setFont(
                    new Font("Arial", Font.BOLD, 17));

            JLabel user = new JLabel("Logged in as: admin  ");

            panel.add(title, BorderLayout.WEST);
            panel.add(user, BorderLayout.EAST);

            return panel;
        }

        JPanel createNavigation() {

            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(
                    panel, BoxLayout.Y_AXIS));

            panel.setBackground(DARK);
            panel.setBorder(
                    new EmptyBorder(15, 10, 15, 10));

            panel.setPreferredSize(
                    new Dimension(180, 0));

            JLabel logo = new JLabel(
                    "SUPPLY CHAIN");

            logo.setForeground(Color.WHITE);
            logo.setFont(
                    new Font("Arial", Font.BOLD, 17));

            logo.setAlignmentX(Component.CENTER_ALIGNMENT);

            panel.add(logo);
            panel.add(Box.createVerticalStrut(20));

            String[] buttons = {
                    "Dashboard",
                    "Shipments",
                    "Tracking",
                    "Inventory",
                    "Suppliers",
                    "Warehouses",
                    "Vehicles",
                    "Alerts",
                    "Reports"
            };

            for (String name : buttons) {

                JButton button = new JButton(name);

                button.setMaximumSize(
                        new Dimension(160, 38));

                button.setAlignmentX(
                        Component.CENTER_ALIGNMENT);

                button.addActionListener(
                        e -> showPage(name));

                panel.add(button);
                panel.add(Box.createVerticalStrut(7));
            }

            panel.add(Box.createVerticalGlue());

            JButton logout = new JButton("Logout");

            logout.setMaximumSize(
                    new Dimension(160, 38));

            logout.setAlignmentX(
                    Component.CENTER_ALIGNMENT);

            logout.addActionListener(e -> {

                dispose();
                new LoginFrame();

            });

            panel.add(logout);

            return panel;
        }

        void showPage(String page) {

            cardLayout.show(contentPanel, page);

            // Refresh screen when selected.
            if (page.equals("Dashboard")) {
                replacePage("Dashboard",
                        new DashboardPanel());
            }

            if (page.equals("Shipments")) {
                replacePage("Shipments",
                        new ShipmentPanel());
            }

            if (page.equals("Tracking")) {
                replacePage("Tracking",
                        new TrackingPanel());
            }

            if (page.equals("Inventory")) {
                replacePage("Inventory",
                        new InventoryPanel());
            }

            if (page.equals("Suppliers")) {
                replacePage("Suppliers",
                        new SupplierPanel());
            }

            if (page.equals("Warehouses")) {
                replacePage("Warehouses",
                        new WarehousePanel());
            }

            if (page.equals("Vehicles")) {
                replacePage("Vehicles",
                        new VehiclePanel());
            }

            if (page.equals("Alerts")) {
                replacePage("Alerts",
                        new AlertPanel());
            }

            if (page.equals("Reports")) {
                replacePage("Reports",
                        new ReportPanel());
            }
        }

        void replacePage(String name, JPanel panel) {

            contentPanel.add(panel, name);
            cardLayout.show(contentPanel, name);
        }
    }

    // ============================================================
    // COMMON PANEL METHODS
    // ============================================================

    static JPanel pagePanel(String title) {

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel heading = new JLabel(title);
        heading.setFont(titleFont);

        panel.add(heading, BorderLayout.NORTH);

        return panel;
    }

    static JTable createTable(String[] columns) {

        DefaultTableModel model =
                new DefaultTableModel(columns, 0) {

                    @Override
                    public boolean isCellEditable(
                            int row, int column) {
                        return false;
                    }
                };

        return new JTable(model);
    }

    static void addRow(JTable table, Object... values) {

        DefaultTableModel model =
                (DefaultTableModel) table.getModel();

        model.addRow(values);
    }

    static JPanel buttonPanel(JButton... buttons) {

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        for (JButton button : buttons) {
            panel.add(button);
        }

        return panel;
    }

    // ============================================================
    // DASHBOARD
    // ============================================================

    static class DashboardPanel extends JPanel {

        DashboardPanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title = new JLabel("Dashboard");
            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            JPanel center = new JPanel();
            center.setLayout(new BoxLayout(
                    center, BoxLayout.Y_AXIS));

            center.add(createSummary());
            center.add(Box.createVerticalStrut(15));

            JLabel recent =
                    new JLabel("Recent Shipments");

            recent.setFont(boldFont);

            center.add(recent);
            center.add(Box.createVerticalStrut(5));

            JTable table = createTable(new String[]{
                    "Shipment ID",
                    "Origin",
                    "Destination",
                    "Status",
                    "Expected Delivery"
            });

            for (Shipment s : shipments) {

                addRow(table,
                        s.id,
                        s.origin,
                        s.destination,
                        s.status,
                        s.expectedDelivery);
            }

            center.add(new JScrollPane(table));

            add(center, BorderLayout.CENTER);
        }

        JPanel createSummary() {

            JPanel panel = new JPanel(
                    new GridLayout(2, 3, 10, 10));

            int total = shipments.size();

            int transit = 0;
            int delivered = 0;
            int delayed = 0;
            int lowStock = 0;

            for (Shipment s : shipments) {

                if (s.status == ShipmentStatus.IN_TRANSIT)
                    transit++;

                if (s.status == ShipmentStatus.DELIVERED)
                    delivered++;

                if (s.status == ShipmentStatus.DELAYED)
                    delayed++;
            }

            for (Inventory i : inventory) {

                if (i.quantity < i.reorderLevel)
                    lowStock++;
            }

            panel.add(summaryLabel(
                    "Total Shipments", total));

            panel.add(summaryLabel(
                    "In Transit", transit));

            panel.add(summaryLabel(
                    "Delivered", delivered));

            panel.add(summaryLabel(
                    "Delayed", delayed));

            panel.add(summaryLabel(
                    "Low Stock", lowStock));

            panel.add(summaryLabel(
                    "Vehicles", vehicles.size()));

            return panel;
        }

        JPanel summaryLabel(String name, int value) {

            JPanel p = new JPanel(
                    new BorderLayout());

            p.setBorder(
                    BorderFactory.createLineBorder(BORDER));

            JLabel label = new JLabel(
                    "<html><center>" +
                            name +
                            "<br><br><b><font size='5'>" +
                            value +
                            "</font></b></center></html>",
                    SwingConstants.CENTER);

            p.add(label);

            return p;
        }
    }

    // ============================================================
    // SHIPMENT MANAGEMENT
    // ============================================================

    static class ShipmentPanel extends JPanel {

        JTable table;
        JTextField searchField;

        ShipmentPanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title = new JLabel(
                    "Shipment Management");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            table = createTable(new String[]{
                    "ID",
                    "Origin",
                    "Destination",
                    "Product",
                    "Vehicle",
                    "Expected Delivery",
                    "Status"
            });

            refreshTable();

            JPanel bottom = new JPanel(
                    new BorderLayout());

            JPanel buttons = new JPanel(
                    new FlowLayout(FlowLayout.LEFT));

            JButton add = new JButton("Add Shipment");
            JButton update = new JButton("Update Status");
            JButton delete = new JButton("Delete");

            searchField = new JTextField(15);

            JButton search = new JButton("Search");

            add.addActionListener(e -> addShipment());

            update.addActionListener(
                    e -> updateShipment());

            delete.addActionListener(
                    e -> deleteShipment());

            search.addActionListener(
                    e -> searchShipment());

            buttons.add(add);
            buttons.add(update);
            buttons.add(delete);
            buttons.add(new JLabel("Search:"));
            buttons.add(searchField);
            buttons.add(search);

            bottom.add(buttons, BorderLayout.NORTH);

            add(new JScrollPane(table),
                    BorderLayout.CENTER);

            add(bottom, BorderLayout.SOUTH);
        }

        void refreshTable() {

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            for (Shipment s : shipments) {

                addRow(table,
                        s.id,
                        s.origin,
                        s.destination,
                        s.product,
                        s.vehicle,
                        s.expectedDelivery,
                        s.status);
            }
        }

        void addShipment() {

            JTextField id =
                    new JTextField();

            JTextField origin =
                    new JTextField();

            JTextField destination =
                    new JTextField();

            JTextField product =
                    new JTextField();

            JTextField vehicle =
                    new JTextField();

            JTextField date =
                    new JTextField("20 Sep 2026");

            JPanel panel = new JPanel(
                    new GridLayout(6, 2, 5, 5));

            panel.add(new JLabel("Shipment ID:"));
            panel.add(id);

            panel.add(new JLabel("Origin:"));
            panel.add(origin);

            panel.add(new JLabel("Destination:"));
            panel.add(destination);

            panel.add(new JLabel("Product:"));
            panel.add(product);

            panel.add(new JLabel("Vehicle:"));
            panel.add(vehicle);

            panel.add(new JLabel("Expected Delivery:"));
            panel.add(date);

            int result = JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    "Add Shipment",
                    JOptionPane.OK_CANCEL_OPTION);

            if (result == JOptionPane.OK_OPTION) {

                if (id.getText().isBlank()) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Shipment ID is required.");
                    return;
                }

                shipments.add(new Shipment(
                        id.getText(),
                        origin.getText(),
                        destination.getText(),
                        product.getText(),
                        vehicle.getText(),
                        date.getText(),
                        ShipmentStatus.CREATED));

                refreshTable();
            }
        }

        void updateShipment() {

            int row = table.getSelectedRow();

            if (row == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "Select a shipment first.");

                return;
            }

            String id =
                    table.getValueAt(row, 0).toString();

            Shipment selected = findShipment(id);

            if (selected == null) return;

            ShipmentStatus status =
                    (ShipmentStatus) JOptionPane.showInputDialog(
                            this,
                            "Select new status:",
                            "Update Shipment",
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            ShipmentStatus.values(),
                            selected.status);

            if (status != null) {

                selected.status = status;

                events.add(new Event(
                        selected.id,
                        new SimpleDateFormat(
                                "dd MMM yyyy HH:mm")
                                .format(new Date()),
                        selected.destination,
                        status.toString()));

                refreshTable();
            }
        }

        void deleteShipment() {

            int row = table.getSelectedRow();

            if (row == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "Select a shipment first.");

                return;
            }

            String id =
                    table.getValueAt(row, 0).toString();

            shipments.removeIf(
                    s -> s.id.equals(id));

            refreshTable();
        }

        void searchShipment() {

            String text =
                    searchField.getText()
                            .trim()
                            .toLowerCase();

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            for (Shipment s : shipments) {

                if (s.id.toLowerCase().contains(text)
                        || s.origin.toLowerCase().contains(text)
                        || s.destination.toLowerCase().contains(text)
                        || s.status.toString()
                        .toLowerCase().contains(text)) {

                    addRow(table,
                            s.id,
                            s.origin,
                            s.destination,
                            s.product,
                            s.vehicle,
                            s.expectedDelivery,
                            s.status);
                }
            }
        }
    }

    // ============================================================
    // TRACKING
    // ============================================================

    static class TrackingPanel extends JPanel {

        JTextField shipmentField;
        JTable table;

        TrackingPanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title =
                    new JLabel("Shipment Tracking");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            JPanel search = new JPanel(
                    new FlowLayout(FlowLayout.LEFT));

            shipmentField =
                    new JTextField(15);

            JButton searchButton =
                    new JButton("Search");

            search.add(new JLabel(
                    "Shipment ID:"));

            search.add(shipmentField);
            search.add(searchButton);

            table = createTable(new String[]{
                    "Date / Time",
                    "Location",
                    "Status"
            });

            searchButton.addActionListener(
                    e -> showTracking());

            JPanel center = new JPanel(
                    new BorderLayout(10, 10));

            center.add(search, BorderLayout.NORTH);
            center.add(new JScrollPane(table),
                    BorderLayout.CENTER);

            add(center, BorderLayout.CENTER);
        }

        void showTracking() {

            String id =
                    shipmentField.getText().trim();

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            Shipment shipment =
                    findShipment(id);

            if (shipment == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Shipment not found.");

                return;
            }

            for (Event event : events) {

                if (event.shipmentId.equals(id)) {

                    addRow(table,
                            event.date,
                            event.location,
                            event.status);
                }
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Current Status: " +
                            shipment.status);
        }
    }

    // ============================================================
    // INVENTORY
    // ============================================================

    static class InventoryPanel extends JPanel {

        JTable table;

        InventoryPanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title =
                    new JLabel("Inventory Management");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            table = createTable(new String[]{
                    "Product ID",
                    "Product",
                    "Warehouse",
                    "Quantity",
                    "Reorder Level",
                    "Stock Status"
            });

            refresh();

            JButton add =
                    new JButton("Add");

            JButton update =
                    new JButton("Update Quantity");

            JButton delete =
                    new JButton("Delete");

            add.addActionListener(
                    e -> addInventory());

            update.addActionListener(
                    e -> updateInventory());

            delete.addActionListener(
                    e -> deleteInventory());

            JPanel buttons =
                    buttonPanel(add, update, delete);

            add(new JScrollPane(table),
                    BorderLayout.CENTER);

            add(buttons, BorderLayout.SOUTH);
        }

        void refresh() {

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            for (Inventory i : inventory) {

                String status =
                        i.quantity < i.reorderLevel
                                ? "LOW STOCK"
                                : "OK";

                addRow(table,
                        i.productId,
                        i.product,
                        i.warehouse,
                        i.quantity,
                        i.reorderLevel,
                        status);
            }
        }

        void addInventory() {

            JTextField id =
                    new JTextField();

            JTextField product =
                    new JTextField();

            JTextField warehouse =
                    new JTextField();

            JTextField quantity =
                    new JTextField();

            JTextField reorder =
                    new JTextField();

            JPanel panel =
                    new JPanel(new GridLayout(5, 2, 5, 5));

            panel.add(new JLabel("Product ID:"));
            panel.add(id);

            panel.add(new JLabel("Product:"));
            panel.add(product);

            panel.add(new JLabel("Warehouse:"));
            panel.add(warehouse);

            panel.add(new JLabel("Quantity:"));
            panel.add(quantity);

            panel.add(new JLabel("Reorder Level:"));
            panel.add(reorder);

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Add Inventory",
                            JOptionPane.OK_CANCEL_OPTION);

            if (result == JOptionPane.OK_OPTION) {

                try {

                    inventory.add(new Inventory(
                            id.getText(),
                            product.getText(),
                            warehouse.getText(),
                            Integer.parseInt(
                                    quantity.getText()),
                            Integer.parseInt(
                                    reorder.getText())));

                    refresh();

                } catch (NumberFormatException ex) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Quantity and reorder level must be numbers.");
                }
            }
        }

        void updateInventory() {

            int row =
                    table.getSelectedRow();

            if (row == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "Select a product.");

                return;
            }

            String id =
                    table.getValueAt(row, 0).toString();

            Inventory selected = null;

            for (Inventory i : inventory) {

                if (i.productId.equals(id)) {
                    selected = i;
                    break;
                }
            }

            if (selected == null) return;

            String value =
                    JOptionPane.showInputDialog(
                            this,
                            "Enter new quantity:");

            if (value == null) return;

            try {

                selected.quantity =
                        Integer.parseInt(value);

                refresh();

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Enter a valid number.");
            }
        }

        void deleteInventory() {

            int row =
                    table.getSelectedRow();

            if (row == -1) return;

            String id =
                    table.getValueAt(row, 0).toString();

            inventory.removeIf(
                    i -> i.productId.equals(id));

            refresh();
        }
    }

    // ============================================================
    // SUPPLIERS
    // ============================================================

    static class SupplierPanel extends JPanel {

        JTable table;

        SupplierPanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title =
                    new JLabel("Supplier Management");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            table = createTable(new String[]{
                    "Supplier ID",
                    "Supplier Name",
                    "Contact",
                    "Email",
                    "Product"
            });

            refresh();

            JButton add =
                    new JButton("Add Supplier");

            JButton delete =
                    new JButton("Delete Supplier");

            add.addActionListener(
                    e -> addSupplier());

            delete.addActionListener(
                    e -> deleteSupplier());

            add(new JScrollPane(table),
                    BorderLayout.CENTER);

            add(buttonPanel(add, delete),
                    BorderLayout.SOUTH);
        }

        void refresh() {

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            for (Supplier s : suppliers) {

                addRow(table,
                        s.id,
                        s.name,
                        s.contact,
                        s.email,
                        s.product);
            }
        }

        void addSupplier() {

            JTextField id =
                    new JTextField();

            JTextField name =
                    new JTextField();

            JTextField contact =
                    new JTextField();

            JTextField email =
                    new JTextField();

            JTextField product =
                    new JTextField();

            JPanel panel =
                    new JPanel(new GridLayout(5, 2, 5, 5));

            panel.add(new JLabel("Supplier ID:"));
            panel.add(id);

            panel.add(new JLabel("Name:"));
            panel.add(name);

            panel.add(new JLabel("Contact:"));
            panel.add(contact);

            panel.add(new JLabel("Email:"));
            panel.add(email);

            panel.add(new JLabel("Product:"));
            panel.add(product);

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Add Supplier",
                            JOptionPane.OK_CANCEL_OPTION);

            if (result == JOptionPane.OK_OPTION) {

                suppliers.add(new Supplier(
                        id.getText(),
                        name.getText(),
                        contact.getText(),
                        email.getText(),
                        product.getText()));

                refresh();
            }
        }

        void deleteSupplier() {

            int row =
                    table.getSelectedRow();

            if (row == -1) return;

            String id =
                    table.getValueAt(row, 0).toString();

            suppliers.removeIf(
                    s -> s.id.equals(id));

            refresh();
        }
    }

    // ============================================================
    // WAREHOUSES
    // ============================================================

    static class WarehousePanel extends JPanel {

        JTable table;

        WarehousePanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title =
                    new JLabel("Warehouse Management");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            table = createTable(new String[]{
                    "Warehouse ID",
                    "Name",
                    "Location",
                    "Capacity",
                    "Occupied",
                    "Utilization"
            });

            refresh();

            JButton add =
                    new JButton("Add Warehouse");

            add.addActionListener(
                    e -> addWarehouse());

            add(new JScrollPane(table),
                    BorderLayout.CENTER);

            add(buttonPanel(add),
                    BorderLayout.SOUTH);
        }

        void refresh() {

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            for (Warehouse w : warehouses) {

                addRow(table,
                        w.id,
                        w.name,
                        w.location,
                        w.capacity,
                        w.occupied,
                        String.format(
                                "%.1f%%",
                                w.utilization()));
            }
        }

        void addWarehouse() {

            JTextField id = new JTextField();
            JTextField name = new JTextField();
            JTextField location = new JTextField();
            JTextField capacity = new JTextField();
            JTextField occupied = new JTextField();

            JPanel panel =
                    new JPanel(new GridLayout(5, 2, 5, 5));

            panel.add(new JLabel("Warehouse ID:"));
            panel.add(id);

            panel.add(new JLabel("Name:"));
            panel.add(name);

            panel.add(new JLabel("Location:"));
            panel.add(location);

            panel.add(new JLabel("Capacity:"));
            panel.add(capacity);

            panel.add(new JLabel("Occupied:"));
            panel.add(occupied);

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Add Warehouse",
                            JOptionPane.OK_CANCEL_OPTION);

            if (result == JOptionPane.OK_OPTION) {

                try {

                    warehouses.add(new Warehouse(
                            id.getText(),
                            name.getText(),
                            location.getText(),
                            Integer.parseInt(
                                    capacity.getText()),
                            Integer.parseInt(
                                    occupied.getText())));

                    refresh();

                } catch (NumberFormatException ex) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Capacity and occupied must be numbers.");
                }
            }
        }
    }

    // ============================================================
    // VEHICLES
    // ============================================================

    static class VehiclePanel extends JPanel {

        JTable table;

        VehiclePanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title =
                    new JLabel("Vehicle / Transport Management");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            table = createTable(new String[]{
                    "Vehicle ID",
                    "Vehicle Number",
                    "Type",
                    "Driver",
                    "Status"
            });

            refresh();

            JButton add =
                    new JButton("Add Vehicle");

            JButton update =
                    new JButton("Update Status");

            add.addActionListener(
                    e -> addVehicle());

            update.addActionListener(
                    e -> updateVehicle());

            add(new JScrollPane(table),
                    BorderLayout.CENTER);

            add(buttonPanel(add, update),
                    BorderLayout.SOUTH);
        }

        void refresh() {

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            for (Vehicle v : vehicles) {

                addRow(table,
                        v.id,
                        v.number,
                        v.type,
                        v.driver,
                        v.status);
            }
        }

        void addVehicle() {

            JTextField id = new JTextField();
            JTextField number = new JTextField();
            JTextField type = new JTextField();
            JTextField driver = new JTextField();

            JPanel panel =
                    new JPanel(new GridLayout(4, 2, 5, 5));

            panel.add(new JLabel("Vehicle ID:"));
            panel.add(id);

            panel.add(new JLabel("Vehicle Number:"));
            panel.add(number);

            panel.add(new JLabel("Type:"));
            panel.add(type);

            panel.add(new JLabel("Driver:"));
            panel.add(driver);

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Add Vehicle",
                            JOptionPane.OK_CANCEL_OPTION);

            if (result == JOptionPane.OK_OPTION) {

                vehicles.add(new Vehicle(
                        id.getText(),
                        number.getText(),
                        type.getText(),
                        driver.getText(),
                        "Available"));

                refresh();
            }
        }

        void updateVehicle() {

            int row =
                    table.getSelectedRow();

            if (row == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "Select a vehicle.");

                return;
            }

            String id =
                    table.getValueAt(row, 0).toString();

            Vehicle selected = null;

            for (Vehicle v : vehicles) {

                if (v.id.equals(id)) {
                    selected = v;
                    break;
                }
            }

            if (selected == null) return;

            String[] statuses = {
                    "Available",
                    "In Transit",
                    "Maintenance",
                    "Delayed"
            };

            String status =
                    (String) JOptionPane.showInputDialog(
                            this,
                            "Select vehicle status:",
                            "Update Vehicle",
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            statuses,
                            selected.status);

            if (status != null) {

                selected.status = status;
                refresh();
            }
        }
    }


    static class AlertPanel extends JPanel {

        JTable table;

        AlertPanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title =
                    new JLabel("Alerts and Exceptions");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            table = createTable(new String[]{
                    "Alert ID",
                    "Type",
                    "Description",
                    "Severity",
                    "Status"
            });

            refresh();

            JButton resolve =
                    new JButton("Resolve Alert");

            resolve.addActionListener(
                    e -> resolveAlert());

            add(new JScrollPane(table),
                    BorderLayout.CENTER);

            add(buttonPanel(resolve),
                    BorderLayout.SOUTH);
        }

        void refresh() {

            DefaultTableModel model =
                    (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            for (Alert a : alerts) {

                addRow(table,
                        a.id,
                        a.type,
                        a.description,
                        a.severity,
                        a.resolved
                                ? "Resolved"
                                : "Open");
            }
        }

        void resolveAlert() {

            int row =
                    table.getSelectedRow();

            if (row == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "Select an alert.");

                return;
            }

            String id =
                    table.getValueAt(row, 0).toString();

            for (Alert a : alerts) {

                if (a.id.equals(id)) {
                    a.resolved = true;
                    break;
                }
            }

            refresh();
        }
    }

    static class ReportPanel extends JPanel {

        JTextArea report;

        ReportPanel() {

            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(20, 20, 20, 20));

            JLabel title =
                    new JLabel("Reports");

            title.setFont(titleFont);

            add(title, BorderLayout.NORTH);

            report = new JTextArea();

            report.setFont(
                    new Font("Monospaced",
                            Font.PLAIN, 14));

            report.setEditable(false);

            generateReport();

            JButton refresh =
                    new JButton("Generate Report");

            refresh.addActionListener(
                    e -> generateReport());

            add(new JScrollPane(report),
                    BorderLayout.CENTER);

            add(refresh,
                    BorderLayout.SOUTH);
        }

        void generateReport() {

            int total = shipments.size();
            int delivered = 0;
            int delayed = 0;
            int transit = 0;
            int lowStock = 0;

            for (Shipment s : shipments) {

                if (s.status ==
                        ShipmentStatus.DELIVERED)
                    delivered++;

                if (s.status ==
                        ShipmentStatus.DELAYED)
                    delayed++;

                if (s.status ==
                        ShipmentStatus.IN_TRANSIT)
                    transit++;
            }

            for (Inventory i : inventory) {

                if (i.quantity <
                        i.reorderLevel)
                    lowStock++;
            }

            StringBuilder text =
                    new StringBuilder();

            text.append(
                    "SUPPLY CHAIN REPORT\n");

            text.append(
                    "=============================\n\n");

            text.append(
                    "Shipment Statistics\n");

            text.append(
                    "-----------------------------\n");

            text.append(
                            "Total Shipments : ")
                    .append(total)
                    .append("\n");

            text.append(
                            "In Transit      : ")
                    .append(transit)
                    .append("\n");

            text.append(
                            "Delivered       : ")
                    .append(delivered)
                    .append("\n");

            text.append(
                            "Delayed         : ")
                    .append(delayed)
                    .append("\n\n");

            text.append(
                    "Inventory Statistics\n");

            text.append(
                    "-----------------------------\n");

            text.append(
                            "Total Products  : ")
                    .append(inventory.size())
                    .append("\n");

            text.append(
                            "Low Stock Items : ")
                    .append(lowStock)
                    .append("\n\n");

            text.append(
                    "Warehouse Statistics\n");

            text.append(
                    "-----------------------------\n");

            text.append(
                            "Total Warehouses: ")
                    .append(warehouses.size())
                    .append("\n");

            for (Warehouse w : warehouses) {

                text.append(
                                w.id)
                        .append(" - ")
                        .append(w.name)
                        .append(" : ")
                        .append(String.format(
                                "%.1f%%",
                                w.utilization()))
                        .append(" utilized\n");
            }

            text.append("\n");

            text.append(
                    "Vehicle Statistics\n");

            text.append(
                    "-----------------------------\n");

            text.append(
                            "Total Vehicles  : ")
                    .append(vehicles.size())
                    .append("\n");

            text.append(
                    "\nOpen Alerts      : ");

            long openAlerts =
                    alerts.stream()
                            .filter(a -> !a.resolved)
                            .count();

            text.append(openAlerts);

            report.setText(text.toString());
        }
    }

    static Shipment findShipment(String id) {

        for (Shipment s : shipments) {

            if (s.id.equalsIgnoreCase(id))
                return s;
        }

        return null;
    }
}